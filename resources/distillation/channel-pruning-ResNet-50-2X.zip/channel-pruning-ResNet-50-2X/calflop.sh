python3 tools.py flop $@
#-model temp/cb_3c_3C4x_mem_bn_vgg.prototxt -weights ../caffe/models/vgg16/cb_3c_VGG16.v2.caffemodel
