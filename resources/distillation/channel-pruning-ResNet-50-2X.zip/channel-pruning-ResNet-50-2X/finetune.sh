caffe train -solver temp/solver.prototxt -weights temp/3c_vgg.caffemodel -gpu $1
