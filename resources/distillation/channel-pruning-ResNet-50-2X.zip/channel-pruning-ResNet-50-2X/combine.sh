python3 train.py -action combine -prototxt temp/3c_3C4x_mem_bn_vgg.prototxt -weights temp/3c_vgg.caffemodel
