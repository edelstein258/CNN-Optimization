All are welcome to create issues, but please google the problem first, and make sure it has not already been reported.

### What steps reproduce the bug?

### What hardware and operating system/distribution are you running?
Operating system:  
CUDA version:  
CUDNN version:  
openCV version:  
BLAS:  
Python version:  

### If the bug is a crash, provide the backtrace.
